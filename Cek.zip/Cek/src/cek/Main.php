<?php

namespace cek;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use jojoe77777\FormAPI\FormAPI; // FormAPI'nin ana sınıfı
use jojoe77777\FormAPI\CustomForm; // CustomForm tipi için gerekli
use onebone\economyapi\EconomyAPI; // EconomyAPI için gerekli
use pocketmine\item\VanillaItems; // Kağıt eşyası için gerekli
use pocketmine\nbt\tag\StringTag; // NBT Tag (eşya verisi) için gerekli
use pocketmine\event\Listener; // Event dinlemek için gerekli
use pocketmine\event\player\PlayerItemUseEvent; // Oyuncu eşya kullanım eventi için gerekli
use cek\commands\CekCommand; // Kendi özel komut sınıfımızı import ediyoruz

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getLogger()->info("§aCek Eklentisi aktif edildi!");

        // Komutumuzu PocketMine-MP'ye kaydet.
        // CekCommand sınıfı, kendisini oluşturmak için Main sınıfının bir örneğini ($this) bekler.
        $this->getServer()->getCommandMap()->register("cek", new CekCommand($this));

        // Eventleri kaydet. Özellikle çeki bozdurma işlemi için PlayerItemUseEvent'i dinleyeceğiz.
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    /**
     * Bu metot, CekCommand sınıfı tarafından çağrılır.
     * Oyuncuya para çekme menüsünü gösterir.
     *
     * @param Player $player Menüyü açacak oyuncu.
     */
    public function openCekForm(Player $player): void {
        // FormAPI eklentisinin sunucuda yüklü ve aktif olup olmadığını kontrol et.
        $formAPI = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        if (!$formAPI instanceof FormAPI) {
            $player->sendMessage("§cFormAPI eklentisi bulunamadı. Lütfen sunucu yöneticisi ile iletişime geçin.");
            return;
        }

        // EconomyAPI eklentisinin sunucuda yüklü ve aktif olup olmadığını kontrol et.
        $economyAPI = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if (!$economyAPI instanceof EconomyAPI) {
            $player->sendMessage("§cEconomyAPI eklentisi bulunamadı. Lütfen sunucu yöneticisi ile iletişime geçin.");
            return;
        }

        // Çekme formunu oluşturup oyuncuya gönder.
        $this->showCekForm($player, $economyAPI); // FormAPI'yi doğrudan parametre olarak geçmeye artık gerek yok
    }

    /**
     * Oyuncuya CustomForm ile para çekme menüsünü gösterir.
     *
     * @param Player $player Formun gönderileceği oyuncu.
     * @param EconomyAPI $economyAPI EconomyAPI örneği.
     */
    private function showCekForm(Player $player, EconomyAPI $economyAPI): void {
        // Yeni FormAPI versiyonlarında CustomForm doğrudan new CustomForm() ile oluşturulur.
        $form = new CustomForm(function (Player $player, ?array $data) use ($economyAPI) {
            // Oyuncu formu kapatırsa (veri null olarak döner).
            if ($data === null) {
                $player->sendMessage("§7Çek işlemi iptal edildi.");
                return;
            }

            $amount = $data[0]; // Formdaki ilk (ve tek) input alanı, girilen miktar.

            // Girilen miktarın sayısal bir değer ve pozitif olup olmadığını kontrol et.
            if (!is_numeric($amount) || (int)$amount <= 0) {
                $player->sendMessage("§cLütfen geçerli bir pozitif miktar girin.");
                return;
            }

            $amount = (int)$amount; // Miktarı tam sayıya çevir.

            // Oyuncunun hesabında yeterli para olup olmadığını kontrol et.
            $playerMoney = $economyAPI->myMoney($player);
            if ($playerMoney < $amount) {
                $player->sendMessage("§cHesabında yeterli para yok! (Mevcut: §e" . $playerMoney . " TL)");
                return;
            }

            // Oyuncunun hesabından parayı düş.
            $economyAPI->reduceMoney($player, $amount);

            // "Çek" eşyasını (kağıt) oluştur.
            $cekItem = VanillaItems::PAPER();
            $cekItem->setCustomName("§aÇek §r§7(Sağ Tıkla Bozdur)"); // Eşyanın görünen adı.
            $cekItem->setLore([ // Eşyanın açıklama metni (lore).
                "§fDeğer: §e" . $amount . " TL",
                "§fOluşturan: §b" . $player->getName()
            ]);

            // Çekin değerini eşyanın NBT (Named Binary Tag) verisine kaydet.
            // Bu, çekin değerini eşya üzerinde güvenli bir şekilde saklamamızı sağlar.
            $cekItem->getNamedTag()->setString("cek_value", (string)$amount);

            // Oluşturulan çeki oyuncunun envanterine ekle.
            if ($player->getInventory()->canAddItem($cekItem)) {
                $player->getInventory()->addItem($cekItem);
                $player->sendMessage("§aHesabından §e" . $amount . " TL §açekildi ve sana bir çek verildi!");
            } else {
                // Eğer oyuncunun envanteri doluysa, parayı geri iade et.
                $economyAPI->addMoney($player, $amount);
                $player->sendMessage("§cEnvanterin dolu olduğu için çek verilemedi, paran hesabına geri yüklendi.");
            }
        });

        // Formun başlığını ve input alanını ayarla.
        $form->setTitle("§0Çek Menüsü");
        $form->addInput("§fKaç Para Çek Oluşturmak İstersin?", "Örnek: 1000", "");

        // Formu oyuncuya gönder.
        $form->sendToPlayer($player);
    }

    /**
     * Oyuncunun eşya kullanma (sağ tıklama/uzun basma) olayını dinler.
     * Eğer kullanılan eşya bir çek ise, onu bozdurur.
     *
     * @param PlayerItemUseEvent $event Tetiklenen eşya kullanım olayı.
     */
    public function onPlayerItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        // Kullanılan eşyanın NBT etiketlerinde "cek_value" olup olmadığını kontrol et.
        // Bu, eşyanın bizim oluşturduğumuz bir çek olup olmadığını anlamamızı sağlar.
        if ($item->getNamedTag()->getTag("cek_value") instanceof StringTag) {
            $cekValue = (int)$item->getNamedTag()->getString("cek_value"); // Çekin değerini NBT'den al.

            // Çek değerinin geçerli (sıfırdan büyük) olup olmadığını kontrol et.
            if ($cekValue <= 0) {
                $player->sendMessage("§cCek geçersiz bir değere sahip.");
                $event->cancel(); // Geçersiz çek ise olayın varsayılan davranışını iptal et.
                return;
            }

            // EconomyAPI eklentisinin hala yüklü olup olmadığını kontrol et.
            $economyAPI = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if (!$economyAPI instanceof EconomyAPI) {
                $player->sendMessage("§cEconomyAPI eklentisi bulunamadı. Lütfen yetkililere bildirin.");
                $event->cancel();
                return;
            }

            // Çeki oyuncunun envanterinden sil (1 adet azalt).
            $item->setCount($item->getCount() - 1);
            $player->getInventory()->setItemInHand($item); // Oyuncunun elindeki eşyayı güncelle.

            // Çekin değerini oyuncunun EconomyAPI hesabına ekle.
            $economyAPI->addMoney($player, $cekValue);
            $player->sendMessage("§aÇeki bozdurdun ve hesabına §e" . $cekValue . " TL §aeklendi!");

            // Eşya kullanım olayını iptal et. Bu, kağıdın normalde yapacağı (örneğin tüketme) gibi
            // varsayılan davranışları engeller.
            $event->cancel();
        }
    }
}
