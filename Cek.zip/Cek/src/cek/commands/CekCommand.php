<?php

namespace cek\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use cek\Main; // Main sınıfımızı kullanmak için

class CekCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        // Komutun adı, açıklaması, kullanımı ve alternatif isimleri
        parent::__construct("cek", "Para çekme menüsünü açar", "/cek", ["çek", "cashout"]);
        
        // Komutu kullanmak için gerekli izin. Bu izni plugin.yml'e eklemelisiniz.
        $this->setPermission("cek.command"); 
        
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        // Komutu sadece oyuncuların kullanabilmesini sağla
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cBu komut sadece oyun içinde kullanılabilir.");
            return true;
        }

        // Komutun algılandığına dair bilgilendirme (isteğe bağlı, hata ayıklama için faydalı)
        // $sender->sendMessage("§aKomut algılandı, menü açılıyor...");

        // Main sınıfındaki menü açma metodunu çağır
        $this->plugin->openCekForm($sender);
        return true;
    }
}
